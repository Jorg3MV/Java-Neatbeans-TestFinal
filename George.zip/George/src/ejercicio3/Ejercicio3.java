/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author pablonoguera
 */
public class Ejercicio3 {
       public static void calcularValorInventario() {
          System.out.println("");
          System.out.println("Ejercicio 3");
          System.out.println("");
          System.out.println("Escribe un programa en Java que lea un archivo de texto llamado \"datos.txt\" \nque contiene información sobre productos (nombre, precio y cantidad en stock). \nCalcula el valor total del inventario y guarda el resultado en un nuevo archivo llamado \"inventario.txt\".\n");
        // Implementa la lógica del ejercicio 3 aquí
        
    }

 
}
