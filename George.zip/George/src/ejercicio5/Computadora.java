
package ejercicio5;


public class Computadora {

}
