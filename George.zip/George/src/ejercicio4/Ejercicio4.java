/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author pablonoguera
 */
public class Ejercicio4 {
       public static void probarVehiculos() {
            System.out.println("");
          System.out.println("Ejercicio 4");
          System.out.println("");
           System.out.println("Define una clase abstracta llamada Vehiculo con métodos abstractos acelerar() y frenar().\nLuego, crea las clases Coche y Bicicleta que extiendan Vehiculo y \nproporcionen una implementación para los métodos abstractos.\n");
        // Implementa la lógica del ejercicio 4 aquí
       
        class Vehiculo { //Clase madre
    public void acelerar(){
    }
    public void frenar(){
        
    }
 
class Coche extends Vehiculo {
    @Override
    public void acelerar() {
        System.out.println("El coche está acelerando.");
    }

    @Override
    public void frenar() {
        System.out.println("El coche está frenando.");
    }
}

class Bicicleta extends Vehiculo {
    @Override
    public void acelerar() {
        System.out.println("La bicicleta está acelerando.");
    }

    @Override
    public void frenar() {
        System.out.println("La bicicleta está frenando.");
    }
}

       }


       }
}
